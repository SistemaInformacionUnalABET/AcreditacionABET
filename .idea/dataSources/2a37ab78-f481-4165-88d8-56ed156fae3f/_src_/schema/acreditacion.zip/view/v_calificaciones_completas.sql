CREATE VIEW v_calificaciones_completas AS
  SELECT
    `grup`.`id_asignatura`            AS `id_asignatura`,
    `grup`.`numero_grupo`             AS `numero_grupo`,
    `indi`.`id_indicador`             AS `id_indicador`,
    `indi`.`identificador_indicador`  AS `identificador_indicador`,
    `eval`.`tipo_evaluacion`          AS `tipo_evaluacion`,
    `acti`.`tipo_actividad`           AS `tipo_actividad`,
    `estu`.`documento`                AS `documento`,
    `cali`.`calificacion`             AS `calificacion`,
    `cali`.`descripcion_calificacion` AS `descripcion_calificacion`,
    `asig_indi`.`periodo`             AS `periodo`,
    `cali`.`fecha_creacion`           AS `fecha_creacion`,
    `cali`.`fecha_modificacion`       AS `fecha_modificacion`,
    `cali`.`observacion`              AS `observacion`,
    `cali`.`evidencia_url`            AS `evidencia_url`
  FROM ((((((((`acreditacion`.`calificaciones` `cali`
    JOIN `acreditacion`.`actividades` `acti` ON ((`cali`.`id_actividad` = `acti`.`id_actividad`))) JOIN
    `acreditacion`.`evaluaciones` `eval` ON ((`eval`.`id_evaluacion` = `acti`.`id_evaluacion`))) JOIN
    `acreditacion`.`asignatura_indicador` `asig_indi`
      ON ((`asig_indi`.`id_asignatura_indicador` = `eval`.`id_asignatura_indicador`))) JOIN
    `acreditacion`.`asignaturas` `asig` ON ((`asig_indi`.`id_asignatura` = `asig`.`id_asignatura`))) JOIN
    `acreditacion`.`indicadores` `indi` ON ((`asig_indi`.`id_indicador` = `indi`.`id_indicador`))) JOIN
    `acreditacion`.`estudiante_grupo` `estu_grup`
      ON ((`estu_grup`.`id_estudiante_grupo` = `cali`.`id_estudiante_grupo`))) JOIN `acreditacion`.`estudiantes` `estu`
      ON ((`estu`.`id_estudiante` = `estu_grup`.`id_estudiante`))) JOIN `acreditacion`.`grupos` `grup`
      ON ((`grup`.`id_grupo` = `estu_grup`.`id_grupo`)));

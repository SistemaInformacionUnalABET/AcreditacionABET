CREATE VIEW v_verificacion_datos AS
  SELECT
    `asig_indi`.`periodo`    AS `periodo`,
    `indi`.`id_indicador`    AS `id_indicador`,
    `grup`.`id_asignatura`   AS `id_asignatura`,
    `grup`.`id_grupo`        AS `id_grupo`,
    `eval`.`tipo_evaluacion` AS `tipo_evaluacion`,
    `acti`.`tipo_actividad`  AS `tipo_actividad`,
    `estu`.`documento`       AS `documento`,
    `estu`.`nombre_completo` AS `nombre`,
    `estu`.`email`           AS `email`,
    `cali`.`calificacion`    AS `calificacion`,
    `cali`.`observacion`     AS `observacion`,
    `cali`.`evidencia_url`   AS `evidencia_url`
  FROM ((((((((`acreditacion`.`calificaciones` `cali`
    JOIN `acreditacion`.`actividades` `acti` ON ((`cali`.`id_actividad` = `acti`.`id_actividad`))) JOIN
    `acreditacion`.`evaluaciones` `eval` ON ((`eval`.`id_evaluacion` = `acti`.`id_evaluacion`))) JOIN
    `acreditacion`.`asignatura_indicador` `asig_indi`
      ON ((`asig_indi`.`id_asignatura_indicador` = `eval`.`id_asignatura_indicador`))) JOIN
    `acreditacion`.`asignaturas` `asig` ON ((`asig_indi`.`id_asignatura` = `asig`.`id_asignatura`))) JOIN
    `acreditacion`.`indicadores` `indi` ON ((`asig_indi`.`id_indicador` = `indi`.`id_indicador`))) JOIN
    `acreditacion`.`estudiante_grupo` `estu_grup`
      ON ((`estu_grup`.`id_estudiante_grupo` = `cali`.`id_estudiante_grupo`))) JOIN `acreditacion`.`estudiantes` `estu`
      ON ((`estu`.`id_estudiante` = `estu_grup`.`id_estudiante`))) JOIN `acreditacion`.`grupos` `grup`
      ON ((`grup`.`id_grupo` = `estu_grup`.`id_grupo`)));
